<?php
$GLOBALS['lang'] = 'fr';
$GLOBALS['auteur'] = 'blog-osml-tir';
$GLOBALS['email'] = 'mail@example.com';
$GLOBALS['nom_du_site'] = 'OSML Tir';
$GLOBALS['description'] = '';
$GLOBALS['keywords'] = 'blog, Osml, tir';
$GLOBALS['racine'] = 'http://tenlemag.com/osmltir/blog/';
$GLOBALS['max_bill_acceuil'] = '10';
$GLOBALS['max_bill_admin'] = '25';
$GLOBALS['max_comm_admin'] = '50';
$GLOBALS['format_date'] = '0';
$GLOBALS['format_heure'] = '0';
$GLOBALS['fuseau_horaire'] = 'UTC';
$GLOBALS['connexion_captcha']= '0';
$GLOBALS['activer_categories']= '1';
$GLOBALS['theme_choisi']= 'yuki';
$GLOBALS['global_com_rule']= '0';
$GLOBALS['comm_defaut_status']= '1';
$GLOBALS['automatic_keywords']= '1';
$GLOBALS['require_email']= '0';
$GLOBALS['max_linx_admin']= '50';
$GLOBALS['dl_link_to_files']= '0';
?>