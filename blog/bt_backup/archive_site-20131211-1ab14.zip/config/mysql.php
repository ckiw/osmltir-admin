<?php
$GLOBALS['mysql_login'] = '';
$GLOBALS['mysql_passwd'] = '';
$GLOBALS['mysql_db'] = '';
$GLOBALS['mysql_host'] = '';

$GLOBALS['sgdb'] = 'sqlite';
