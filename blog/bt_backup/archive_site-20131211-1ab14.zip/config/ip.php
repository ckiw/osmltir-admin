<?php
$GLOBALS['old_ip'] = '109.24.241.130';
$GLOBALS['old_time'] = '20131211172805';
?>